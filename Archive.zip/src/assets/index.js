export { default as background_image } from "./banner_image.png";

export { default as logo_bg } from "./logos/logo-bg.png";
export { default as logo_bg_1 } from "./logos/logo-bg-1.png";
export { default as logo_bg_2 } from "./logos/logo-bg-2.png";
export { default as logo_bg_3 } from "./logos/logo-bg-3.png";
export { default as logo_bg_4 } from "./logos/logo-bg-4.png";
