// here we add all base urls and keys

// Base URLS
// export const base_uri = process.env.REACT_APP_API_BASE_URL;
export const base_uri = "http://3.133.177.189:81";

// Keys
// export const secret_key = process.env.REACT_APP_API_SECRET_KEY;
